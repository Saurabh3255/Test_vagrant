package com.ipl.testvagrant;

public class Team 
	{
		String name;
		int point;
		char[]ch;
		public Team(String name, int point, char[] ch) {
			super();
			this.name = name;
			this.point = point;
			this.ch = ch;
		}
		public String toString()						//toString method is override to give the results .
		{
			String s1="";
			s1=name+" "+point+" ";
			for(int i=0;i<ch.length;i++)
			{
				s1=s1+ch[i];
			}
			return s1;
		}

	}


