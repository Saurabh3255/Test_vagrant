package com.ipl.testvagrant;
import java.util.LinkedList;
import java.util.Scanner;

public class Ipl 
{
	static Scanner sc=new Scanner(System.in);    
	static LinkedList duc=new LinkedList();			// Created this linked list to add filter ref to get avg.
	public static void main(String[] args) 
	{
		LinkedList ll=new LinkedList();				//Created this Linked list to add the data.
		
		ll.add(new Team("GT",20,new char[]{'w','w','l','l','w'}));
		ll.add(new Team("LSG",18,new char[]{'w','l','l','w','w'}));
		ll.add(new Team("RR",16,new char[]{'w','l','w','l','l'}));
		ll.add(new Team("DC",14,new char[]{'w','w','l','w','l'}));
		ll.add(new Team("RCB",14,new char[]{'l','w','w','l','l'}));
		ll.add(new Team("KKR",12,new char[]{'l','w','w','l','w'}));
		ll.add(new Team("PBKS",12,new char[]{'l','w','l','w','l'}));
		ll.add(new Team("SRH",12,new char[]{'w','l','l','l','l'}));
		ll.add(new Team("CSK",8,new char[]{'l','l','w','l','w'}));
		ll.add(new Team("MI",6,new char[]{'l','w','l','w','w'}));
		
		System.out.println("The Filter Teams are ");
		for(int i=0;i<ll.size();i++)
		{
			Team t=(Team)ll.get(i);
			isWinOrLoss(t);															//method call statement to find 2 consecutive Losses.
		}
		System.err.println("_______________________________________________________");
		
		System.out.println("For Nth Consecutive Win or Losses");
		System.out.println("You want to check win or loss");
		String s1=sc.next();
		s1=s1.toLowerCase();
		char c1=s1.charAt(0);
		System.out.println("How many times u want to check");
		int c2=sc.nextInt();
		for(int i=0;i<ll.size();i++)
		{
			Team t=(Team)ll.get(i);													//downcasting the  linked list ref to team.
			isDynamic(t,c1,c2);														//method call statement 
		}
		System.err.println("_______________________________________________________");
		average(duc);
		
	}
	public static void isDynamic(Team t,char c1,int c2)      //created this method for Nth consecutive WIN or LOSSES. 
	{
		char[]c3=t.ch;										//t.ch[] we are storing this char[]
	     int c=0;
		for(int i=0;i<c3.length;i++)
		{
			if(c1==c3[i])							//cond to check user enter input as win/loss with team.char object with char index.
			{
				c++;								//increment of count++ to check 2 consecutive losses/
				if(c==c2)								//if count is matched with c3 than we are adding this to filter linkedlist.
				{
					System.out.println(t);
					duc.add(t);							//adding filter teams to linked list to get avg.
					break;
				}
			}
			else										//else we dont find keep the count=0, for this for-loop.
			{
				c=0;
			}
		}
	}
	public static void isWinOrLoss(Team t)				//created this method 2 consecutive Win or Losses.
	{
		char[]ch=t.ch;									//the team.char ref we are storing to char[].
		for(int i=0;i<ch.length;i++)
		{
			if(i!=ch.length-1)							//cond to check till the length
			{
				if(ch[i]=='l'&&ch[i+1]=='l')			// cond to check 2 consecutive losses. 
				{
					System.err.println(t);
							
					break;
				}
			}
		}
	}
	public static void average(LinkedList l)
	{
		double average=0;
		for(int i=0;i<l.size();i++)
		{
			Team t=(Team)l.get(i);							//downcasting from linkedlist to team object.
			average+=t.point;								//avg + points to get avg.
		}
		System.err.println("Average of "+average/l.size());				//diving the avg to total size of linkedlist.
	}

}